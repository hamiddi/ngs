#!/bin/bash
###############################################################
#               Amplicon-based genomic pipeline using qiime2
#               Bioinformatics - Hamid D. Ismail, Ph.D.
#                        de Novo clustering  method
###############################################################
#1- Create the project directories
mkdir PRJEB24421
cd PRJEB24421
mkdir fastqs

#2- save the run ids in a text file "runid_16SrRNA_gene.txt"

#3- downloading the data from the NCBI SRA
while read f;
do
   fasterq-dump --progress --outdir fastqs "$f"
done < ../assets/runid_16SrRNA_gene.txt
#4- Mannualy create the sample metadata file (sample-metadata.tsv)
#5- Creating a manifest file (manifest.txt)
bash ../assets/create_manifest.sh
#6- Using manifest file as an input, import the raw data (fastq files) as artifact
mkdir input_artifacts
qiime tools import \
 --type 'SampleData[PairedEndSequencesWithQuality]' \
 --input-format PairedEndFastqManifestPhred33 \
 --input-path ../assets/manifest.txt \
 --output-path input_artifacts/main-yoga.qza

##Make a visualization to the data
mkdir viz
qiime demux summarize \
   --i-data input_artifacts/main-yoga.qza \
   --o-visualization viz/main-yoga-qc.qzv
#Visualize in the Internet browser
#qiime tools view viz/main-yoga-qc.qzv

#7- De novo clustering to produce OTUs
#a- merge reads
qiime vsearch merge-pairs \
  --i-demultiplexed-seqs input_artifacts/main-yoga.qza \
  --p-allowmergestagger \
  --o-merged-sequences input_artifacts/yoga-merged.qza

#b- Sequence dereplication
qiime vsearch dereplicate-sequences \
  --i-sequences input_artifacts/yoga-merged.qza \
  --o-dereplicated-table input_artifacts/derep-yoga-merged-table.qza \
  --o-dereplicated-sequences input_artifacts/derep-yoga-merged-seqs.qza

#c- de novo clustering
mkdir denovo
qiime vsearch cluster-features-de-novo \
  --i-table input_artifacts/derep-yoga-merged-table.qza \
  --i-sequences input_artifacts/derep-yoga-merged-seqs.qza \
  --p-perc-identity 0.99 \
  --o-clustered-table denovo/table-yoga-denovo.qza \
  --o-clustered-sequences denovo/rep-seqs-yoga-denovo.qza

#d- Summarize the data table
qiime feature-table summarize \
  --i-table denovo/table-yoga-denovo.qza \
  --m-sample-metadata-file ../assets/sample-metadata.tsv \
  --o-visualization denovo/table-yoga-denovo.qzv
#qiime tools view denovo/table-yoga-denovo.qzv


#8- Filter for for frequency per sample and abundance
#a- Remove samples with low frequency
# removes the samples with a total frequency less than 100
# from feature table created with DADA2 denoising and then
# it creates a visualization and views it on the Internet browser
qiime feature-table filter-samples \
  --i-table denovo/table-yoga-denovo.qza \
  --p-min-frequency 100 \
  --o-filtered-table denovo/table_sample_filtered_denovo.qza

qiime feature-table summarize \
  --i-table denovo/table_sample_filtered_denovo.qza \
  --m-sample-metadata-file ../assets/sample-metadata.tsv \
  --o-visualization denovo/table_sample_freq_filtered_yoga_denovo.qzv
#qiime tools view denovo/table_sample_freq_filtered_yoga_denovo.qzv


#b- Remove low abundance features from a feature table.
qiime feature-table filter-features \
  --i-table denovo/table_sample_filtered_denovo.qza \
  --p-min-frequency 20 \
  --o-filtered-table denovo/table_feat_sample_freq_filtered_yoga_denovo.qza

qiime feature-table summarize \
  --i-table denovo/table_feat_sample_freq_filtered_yoga_denovo.qza \
  --m-sample-metadata-file ../assets/sample-metadata.tsv \
  --o-visualization denovo/table_feat_sample_freq_filtered_yoga_denovo.qzv
#qiime tools view denovo/table_feat_sample_freq_filtered_yoga_denovo.qzv


#9- Taxonomic assignment
#a- download database to be used with BLAST 
wget https://gg-sg-web.s3-us-west-2.amazonaws.com/downloads/greengenes_database/gg_13_5/gg_13_5_otus.tar.gz \
        --no-check-certificate
tar vxf gg_13_5_otus.tar.gz
rm gg_13_5_otus.tar.gz
#b- import the reference OTUs as artifact
mkdir taxonomy
qiime tools import \
  --type 'FeatureData[Sequence]' \
  --input-path gg_13_5_otus/rep_set/99_otus.fasta \
  --output-path denovo/99_otus.qza
#c- Import reference taxonomy 
qiime tools import \
  --type 'FeatureData[Taxonomy]' \
  --input-format HeaderlessTSVTaxonomyFormat \
  --input-path gg_13_5_otus/taxonomy/99_otu_taxonomy.txt \
  --output-path denovo/99_otu_taxonomy.qza
#d- BLAST-based classifier
qiime feature-classifier classify-consensus-blast \
  --i-query denovo/rep-seqs-yoga-denovo.qza \
  --i-reference-reads denovo/99_otus.qza \
  --i-reference-taxonomy denovo/99_otu_taxonomy.qza \
  --p-perc-identity 0.97 \
  --o-classification taxonomy/blast_tax_yoga_denovo.qza \
  --o-search-results taxonomy/blast_search_results_tax_yoga_denovo.qza \
  --verbose
#e- Visualizing the BLAST-based taxonomy assignment:
qiime metadata tabulate \
  --m-input-file taxonomy/blast_tax_yoga_denovo.qza \
  --o-visualization taxonomy/blast_tax_yoga_denovo.qzv
#qiime tools view taxonomy/blast_tax_yoga_denovo.qzv

#f-taxa plot
mkdir graphs
qiime taxa barplot \
  --i-table denovo/table_feat_sample_freq_filtered_yoga_denovo.qza \
  --i-taxonomy taxonomy/blast_tax_yoga_denovo.qza \
  --m-metadata-file ../assets/sample-metadata.tsv \
  --o-visualization graphs/blast_tax_yoga_denovo_barplot.qzv
#qiime tools view graphs/blast_tax_yoga_denovo_barplot.qzv

#g- Grouping samples by a condition 
#“group” column of the sample metadata file.
qiime feature-table group \
  --i-table denovo/table_feat_sample_freq_filtered_yoga_denovo.qza \
  --p-axis sample \
  --m-metadata-file ../assets/sample-metadata.tsv \
  --m-metadata-column Group \
  --p-mode sum \
  --o-grouped-table denovo/groupedby-yoga-table-denovo.qza

qiime taxa barplot \
  --i-table denovo/groupedby-yoga-table-denovo.qza \
  --i-taxonomy taxonomy/blast_tax_yoga_denovo.qza \
  --m-metadata-file ../assets/group_metadata.tsv \
  --o-visualization graphs/groupedby-yoga-barplot-denovo.qzv
#qiime tools view graphs/groupedby-yoga-barplot-denovo.qzv

#10- Phylogenetic tree
mkdir trees
#a- multiple sequence alignment
qiime alignment mafft \
  --i-sequences denovo/rep-seqs-yoga-denovo.qza \
  --o-alignment trees/aligned-rep-seqs_yoga_denovo.qza

#b- Masking sites of low information
qiime alignment mask \
  --i-alignment trees/aligned-rep-seqs_yoga_denovo.qza \
  --o-masked-alignment trees/masked-aligned-rep-seqs_yoga_denovo.qza

#c- Creating a tree
qiime phylogeny fasttree \
  --i-alignment trees/masked-aligned-rep-seqs_yoga_denovo.qza \
  --o-tree trees/unrooted-denovo-tree.qza

#d- Midpoint rooting
qiime phylogeny midpoint-root \
  --i-tree trees/unrooted-denovo-tree.qza \
  --o-rooted-tree trees/rooted-denovo-tree.qza
#e-expport tree to NEWICK file format
qiime tools export \
  --input-path trees/unrooted-denovo-tree.qza \
  --output-path trees/unrooted
qiime tools export \
  --input-path trees/rooted-denovo-tree.qza \
  --output-path trees/rooted

#11- Diversity
qiime diversity core-metrics-phylogenetic \
 --i-phylogeny trees/rooted-denovo-tree.qza \
 --i-table denovo/table_feat_sample_freq_filtered_yoga_denovo.qza \
 --p-sampling-depth 100 \
 --m-metadata-file ../assets/sample-metadata.tsv \
 --output-dir diversity-indices

#a- Alpha diversity
#a1- Faith’s phylogenetic diversity index
#A higher PD indicates more richness or diversity in the sample
qiime diversity alpha-group-significance \
 --i-alpha-diversity diversity-indices/faith_pd_vector.qza \
 --m-metadata-file ../assets/sample-metadata.tsv \
 --o-visualization diversity-indices/faith-pd-group-significance.qzv
#qiime tools view diversity-indices/faith-pd-group-significance.qzv

#a2- Shannon’s diversity index:
# It is between 1.5 and 3.5. The higher the value of H, the higher the diversity of taxa in a sample
qiime diversity alpha-group-significance \
 --i-alpha-diversity diversity-indices/shannon_vector.qza \
 --m-metadata-file ../assets/sample-metadata.tsv \
 --o-visualization diversity-indices/shannon-group-significance.qzv 
#qiime tools view diversity-indices/shannon-group-significance.qzv


#b- Beta diversity
#b1- weighted UniFrac distance index
qiime diversity beta-group-significance \
 --i-distance-matrix diversity-indices/weighted_unifrac_distance_matrix.qza \
 --m-metadata-file ../assets/sample-metadata.tsv \
 --m-metadata-column Group \
 --o-visualization \
  diversity-indices/weighted-unifrac-life-stage-significance.qzv \
 --p-pairwise
#qiime tools view diversity-indices/weighted-unifrac-life-stage-significance.qzv

# use Emperor tool to explore the microbial community composition using principal coordinates (PCoA)
qiime emperor plot \
 --i-pcoa diversity-indices/weighted_unifrac_pcoa_results.qza \
 --m-metadata-file ../assets/sample-metadata.tsv \
 --o-visualization diversity-indices/weighted-unifrac-emperor-life-stage.qzv
#qiime tools view diversity-indices/weighted-unifrac-emperor-life-stage.qzv






