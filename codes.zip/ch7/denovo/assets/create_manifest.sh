
#Creating a manifest file
###############################
#a- make file name and absolute path
cd fastqs
find "$PWD"/*.fastq -type f -printf '%f %h/%f\n' > tmp.txt
#b- remove _1/2.fastq
awk '{ gsub(/_[12].fastq/,",", $1); print } ' tmp.txt > tmp2.txt
#remove space
cat tmp2.txt | sed -r 's/\s+//g' > tmp3.txt
n=$(ls -l *1.fastq|wc -l)
#create a direction column
seq $n | sed "c forward\nreverse" > tmp4.txt
#add direction column
paste tmp3.txt tmp4.txt | column -s $'' -t > tmp5.txt
#replace space with comma
sed -e 's/\s\+/,/g' tmp5.txt > ../../assets/manifest.txt 
#add column names
sed -i '1s/^/sample-id,absolute-filepath,direction\n/' ../../assets/manifest.txt
rm tmp*.txt
cd ..

