#!/bin/bash
###############################################################
#               Amplicon-based genomic pipeline using qiime2
#               Bioinformatics - Hamid D. Ismail, Ph.D.
#                         DADA2 denoising method
# Book: Bioinformatics: A Practical Guide to Next Generation Sequencing Data Analysis
#       by Hamid D. Ismail, Ph.D.
###############################################################
#1- Create the project directories
mkdir PRJEB24421
cd PRJEB24421
mkdir fastqs

#2- save the run ids in a text file if the files from NCBI SRA.

#3- downloading the data from the NCBI SRA
while read f;
do
   fasterq-dump --progress --outdir fastqs "$f"
done < ../assets/runid_16SrRNA_gene.txt
#4- Manually create the sample metadata file (sample-metadata.tsv)
##  This files includes your study design that may include the sample ids
##  and the experimental conditions. This will help you in the analysis.
##  See the assets directory 

#5- Creating a manifest file (manifest.txt): You can create this manually 
##  or programmatically.
##  The manifest file includes the sample ids, fastq file path, and directions.
##  See the manifest directory.
bash ../assets/create_manifest.sh


#6- Import the raw data as an artifact
##  Using manifest file as an input, import the raw data (fastq files) as an artifact
##  All raw data (fastq files) will be compressed in a single artifact with ".qza" extension.
mkdir input_artifacts
qiime tools import \
 --type 'SampleData[PairedEndSequencesWithQuality]' \
 --input-format PairedEndFastqManifestPhred33 \
 --input-path ../assets/manifest.txt \
 --output-path input_artifacts/main-yoga.qza

## Make a visualization to the data
## You can create avisualization to the  imported data and its quality.
## Visualization includes statistics, and interactive quality report.
mkdir viz
qiime demux summarize \
   --i-data input_artifacts/main-yoga.qza \
   --o-visualization viz/main-yoga-qc.qzv
## Visualize in the Internet browser
#qiime tools view viz/main-yoga-qc.qzv

#7- Denoising with dada2
##  Denoising takes the raw data artifact as input and it produces a table of
##  the representative sequences as features or amplicon sequence variants (ASVs) and 
##  a statistics report. 
mkdir dada2
qiime dada2 denoise-paired \
  --i-demultiplexed-seqs input_artifacts/main-yoga.qza \
  --p-trim-left-f 0 \
  --p-trim-left-r 0 \
  --p-trunc-len-f 250 \
  --p-trunc-len-r 250 \
  --p-n-threads 4 \
  --o-representative-sequences dada2/rep-seqs_yoga_dada2.qza \
  --o-table dada2/table_yoga_dada2.qza \
  --o-denoising-stats dada2/stats_yoga_dada2.qza

## Create a tabular visualization to the denosing statistics report
qiime metadata tabulate \
   --m-input-file dada2/stats_yoga_dada2.qza \
   --o-visualization dada2/stats_yoga_dada2.qzv
#qiime tools view dada2/stats_yoga_dada2.qzv

#8- Filtering: 
#a- Remove samples with low frequency from the representative sequence table
# removes the samples with a total frequency less than 100
# from feature table created with DADA2 denoising and then
# it creates a visualization and views it on the Internet browser
qiime feature-table filter-samples \
  --i-table dada2/table_yoga_dada2.qza \
  --p-min-frequency 100 \
  --o-filtered-table dada2/table_sample_filtered_dada2.qza

qiime feature-table summarize \
  --i-table dada2/table_sample_filtered_dada2.qza \
  --m-sample-metadata-file ../assets/sample-metadata.tsv \
  --o-visualization dada2/table_sample_freq_filtered_yoga_dada2.qzv
#qiime tools view dada2/table_sample_freq_filtered_yoga_dada2.qzv

#b- Remove low abundance features from a feature table and create a tabular visualization.
qiime feature-table filter-features \
  --i-table dada2/table_sample_filtered_dada2.qza \
  --p-min-frequency 20 \
  --o-filtered-table dada2/table_feat_sample_freq_filtered_yoga_dada2.qza

qiime feature-table summarize \
  --i-table dada2/table_feat_sample_freq_filtered_yoga_dada2.qza \
  --m-sample-metadata-file ../assets/sample-metadata.tsv \
  --o-visualization dada2/table_feat_sample_freq_filtered_yoga_dada2.qzv
#qiime tools view dada2/table_feat_sample_freq_filtered_yoga_dada2.qzv


#9- Taxonomic assignment
##  The database files include curated features (OTUs) and and their taxonomic classification.
#a- download database to be used with BLAST 
wget https://gg-sg-web.s3-us-west-2.amazonaws.com/downloads/greengenes_database/gg_13_5/gg_13_5_otus.tar.gz \
        --no-check-certificate
tar vxf gg_13_5_otus.tar.gz
rm gg_13_5_otus.tar.gz
#b- import the reference OTUs as an artifact
mkdir taxonomy
qiime tools import \
  --type 'FeatureData[Sequence]' \
  --input-path gg_13_5_otus/rep_set/99_otus.fasta \
  --output-path dada2/99_otus.qza
#c- Import reference taxonomy as an artifcat 
qiime tools import \
  --type 'FeatureData[Taxonomy]' \
  --input-format HeaderlessTSVTaxonomyFormat \
  --input-path gg_13_5_otus/taxonomy/99_otu_taxonomy.txt \
  --output-path dada2/99_otu_taxonomy.qza
#d- Use a taxonomy classifier for taxonomic assignment 
##  You can use the BLAST-based or a machine learning classifier 
##BLAST-based classifier
qiime feature-classifier classify-consensus-blast \
  --i-query dada2/rep-seqs_yoga_dada2.qza \
  --i-reference-reads dada2/99_otus.qza \
  --i-reference-taxonomy dada2/99_otu_taxonomy.qza \
  --p-perc-identity 0.97 \
  --o-classification taxonomy/blast_tax_yoga_dada2.qza \
  --o-search-results taxonomy/blast_search_results_tax_yoga_dada2.qza \
  --verbose
#e- Visualizing the BLAST-based taxonomy assignment:
qiime metadata tabulate \
  --m-input-file taxonomy/blast_tax_yoga_dada2.qza \
  --o-visualization taxonomy/blast_tax_yoga_dada2.qzv
#qiime tools view taxonomy/blast_tax_yoga_dada2.qzv

#f-taxa plot: notice we use sample metadata. Why?
mkdir graphs
qiime taxa barplot \
  --i-table dada2/table_feat_sample_freq_filtered_yoga_dada2.qza \
  --i-taxonomy taxonomy/blast_tax_yoga_dada2.qza \
  --m-metadata-file ../assets/sample-metadata.tsv \
  --o-visualization graphs/blast_tax_yoga_dada2_barplot.qzv
#qiime tools view graphs/blast_tax_yoga_dada2_barplot.qzv

#g- Grouping samples by a condition - study design
#“group” column of the sample metadata file.
qiime feature-table group \
  --i-table dada2/table_feat_sample_freq_filtered_yoga_dada2.qza \
  --p-axis sample \
  --m-metadata-file ../assets/sample-metadata.tsv \
  --m-metadata-column Group \
  --p-mode sum \
  --o-grouped-table dada2/groupedby-yoga-table-dada2.qza

qiime taxa barplot \
  --i-table dada2/groupedby-yoga-table-dada2.qza \
  --i-taxonomy taxonomy/blast_tax_yoga_dada2.qza \
  --m-metadata-file ../assets/group_metadata.tsv \
  --o-visualization graphs/groupedby-yoga-barplot-dada2.qzv
#qiime tools view graphs/groupedby-yoga-barplot-dada2.qzv

#10- Phylogenetic tree
mkdir trees
#a- multiple sequence alignment
qiime alignment mafft \
  --i-sequences dada2/rep-seqs_yoga_dada2.qza \
  --o-alignment trees/aligned-rep-seqs_yoga_dada2.qza
#b- Masking sites of low information
qiime alignment mask \
  --i-alignment trees/aligned-rep-seqs_yoga_dada2.qza \
  --o-masked-alignment trees/masked-aligned-rep-seqs_yoga_dada2.qza
#c- Creating a tree
qiime phylogeny fasttree \
  --i-alignment trees/masked-aligned-rep-seqs_yoga_dada2.qza \
  --o-tree trees/unrooted-dada2-tree.qza
#d- Midpoint rooting
qiime phylogeny midpoint-root \
  --i-tree trees/unrooted-dada2-tree.qza \
  --o-rooted-tree trees/rooted-dada2-tree.qza
#e-expport tree to NEWICK file format
qiime tools export \
  --input-path trees/unrooted-dada2-tree.qza \
  --output-path trees/unrooted_dada2
qiime tools export \
  --input-path trees/rooted-dada2-tree.qza \
  --output-path trees/rooted_dada2

#11- Diversity
qiime diversity core-metrics-phylogenetic \
 --i-phylogeny trees/rooted-dada2-tree.qza \
 --i-table dada2/table_feat_sample_freq_filtered_yoga_dada2.qza \
 --p-sampling-depth 100 \
 --m-metadata-file ../assets/sample-metadata.tsv \
 --output-dir diversity-indices
#a- Alpha diversity
#a1- Faith’s phylogenetic diversity index 
#A higher PD indicates more richness or diversity in the sample
qiime diversity alpha-group-significance \
 --i-alpha-diversity diversity-indices/faith_pd_vector.qza \
 --m-metadata-file ../assets/sample-metadata.tsv \
 --o-visualization diversity-indices/faith-pd-group-significance.qzv
#qiime tools view diversity-indices/faith-pd-group-significance.qzv

#a2- Shannon’s diversity index: 
# It is between 1.5 and 3.5. The higher the value of H, the higher the diversity of taxa in a sample
qiime diversity alpha-group-significance \
 --i-alpha-diversity diversity-indices/shannon_vector.qza \
 --m-metadata-file ../assets/sample-metadata.tsv \
 --o-visualization diversity-indices/shannon-group-significance.qzv 
#qiime tools view diversity-indices/shannon-group-significance.qzv

#b- Beta diversity
#b1- weighted UniFrac distance index
qiime diversity beta-group-significance \
 --i-distance-matrix diversity-indices/weighted_unifrac_distance_matrix.qza \
 --m-metadata-file ../assets/sample-metadata.tsv \
 --m-metadata-column Group \
 --o-visualization \
  diversity-indices/weighted-unifrac-life-stage-significance.qzv \
 --p-pairwise
#qiime tools view diversity-indices/weighted-unifrac-life-stage-significance.qzv

# use Emperor tool to explore the microbial community composition using principal coordinates (PCoA)
qiime emperor plot \
 --i-pcoa diversity-indices/weighted_unifrac_pcoa_results.qza \
 --m-metadata-file ../assets/sample-metadata.tsv \
 --o-visualization diversity-indices/weighted-unifrac-emperor-life-stage.qzv
#qiime tools view diversity-indices/weighted-unifrac-emperor-life-stage.qzv




