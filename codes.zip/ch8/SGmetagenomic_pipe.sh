#CSE815 - Bioinformatics - Hamid D. Ismail, Ph.D.
################################################
#Shotgun metagenomics data analysis pipeline
###############################################
#1-Make a project directory and download the fastq files
########################################################
projDir=PRJNA986283
mkdir ${projDir}
cd ${projDir}
mkdir fastqs
mkdir refgenome
mkdir bam 
threads=8
#2-download and compress fastq files (raw data)
###############################################
for runid in $(cat ../runids.txt)
do
  fasterq-dump ${runid} --threads ${threads} --progress --outdir fastqs
done
gzip fastqs/*.fastq
#3-download, decompress, and index human (host) human genome
#############################################################
#3a-download and decompress the ref genome
#******************                             #?????????????????????????????
wget https://hgdownload.soe.ucsc.edu/goldenPath/hg38/bigZips/hg38.fa.gz --no-check-certificate \
	-P refgenome
gzip -d refgenome/hg38.fa.gz
#3b-Index the ref genome with samtools faidx
#****************************************
samtools faidx refgenome/hg38.fa

#4- Indexing with the mapper and mapping the reads
#################################################
#4a-Index the ref genome with the aligner
bwa index refgenome/hg38.fa
#4b Mapping, converting SAM to BAM, sort, index BAM
for f in $(ls fastqs/*.fastq.gz | sed -e 's/_1.fastq.gz//' -e 's/_2.fastq.gz//' | sort -u);  
do
    runid=$(echo ${f} | cut -d/ -f2 | cut -d. -f1)
    #4a-Map reads to the host ref genome
    bwa mem -t ${threads} \
       refgenome/hg38.fa \
       ${f}_1.fastq.gz ${f}_2.fastq.gz > bam/${runid}.sam
    #4b-Convert SAM into BAM
    samtools view -@ ${threads} -h -uS \
    -o bam/${runid}.bam \
    bam/${runid}.sam
    #remove sam to save space
    rm bam/${runid}.sam
    #4c-Sort BAM
    samtools sort -@ ${threads} \
    bam/${runid}.bam \
    -o bam/${runid}_sorted.bam
    rm bam/${runid}.bam
    #4d-Index BAM
    samtools index -@ ${threads} bam/${runid}_sorted.bam
done

#5-separate the unaligned reads into fastq files
mkdir fastqs_genomics
mkdir kaiju_output
for f in $(ls bam/*_sorted.bam)
do
  runid=$(echo ${f} | cut -d/ -f2 | cut -d_ -f1)
  #5a-transfer unmapped reads into a separate BAM file  
  samtools view \
   -b -f 12 \
   -F 256 \
   ${f} \
   > bam/${runid}_unmapped.bam
  #5b-sort the new created bam file of unmapped reads 
  samtools sort \
   -n -m 5G \
   -@ ${threads} bam/${runid}_unmapped.bam \
   -o bam/${runid}_unmapped_sorted.bam
  #5c-Index the new created sorted bam file
  samtools index bam/${runid}_unmapped_sorted.bam
  #5d-create forward and reverse fastq files from the bam file (pure genomics reads
  samtools fastq -@ ${threads} bam/${runid}_unmapped_sorted.bam \
    -1 fastqs_genomics/${runid}_genomics_1.fastq.gz \
    -2 fastqs_genomics/${runid}_genomics_2.fastq.gz \
    -0 /dev/null -s /dev/null -n
  #5e-Use a classifier for microbial identification
  kaiju -t /hpchome/cse_classes/cse815/hamid2/software/kaiju/kaijuDB/nodes.dmp \
        -f /hpchome/cse_classes/cse815/hamid2/software/kaiju/kaijuDB/kaiju_db_refseq.fmi \
        -i fastqs_genomics/${runid}_genomics_1.fastq.gz \
        -j fastqs_genomics/${runid}_genomics_1.fastq.gz \
        -o kaiju_output/${runid}.out \
        -a greedy \
        -z ${threads} -v
  #5f-Make a report
  kaiju2table -t /hpchome/cse_classes/cse815/hamid2/software/kaiju/kaijuDB/nodes.dmp \
              -n /hpchome/cse_classes/cse815/hamid2/software/kaiju/kaijuDB/names.dmp \
              -r species \
              -o kaiju_output/${runid}_table.tsv \
              kaiju_output/${runid}.out \
	      -l taxonomic,species,separated,by,commas
  done;
#count unmapped reads
##samtools view -c -f 4 SRR25006891_sorted.bam
#count mapped reads 
##samtools view -c -F 4 SRR25006891_sorted.bam
